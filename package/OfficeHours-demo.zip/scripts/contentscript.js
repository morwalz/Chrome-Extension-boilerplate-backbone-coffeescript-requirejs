(function() {
  var runTime;

  runTime = window.chrome.runtime;

  window.addEventListener("message", function(event) {
    switch (event.data.type) {
      case "AUTH_SUCCESS":
        return runTime.sendMessage({
          'type': 'AUTH_SUCCESS'
        });
      case "IS_CHROME_EXT_PRESENT?":
        return window.postMessage({
          'type': 'CHROME_EXT_PRESENT',
          'text': 'Yes, I am there'
        }, "*");
      case "LOGOUT":
        console.log('logout');
        return runTime.sendMessage({
          'type': 'LOGOUT'
        });
    }
  }, false);

}).call(this);
