(function() {
  var ExtendedScript;

  ExtendedScript = (function() {
    var _this = this;

    function ExtendedScript() {}

    chrome.runtime.sendMessage({
      greeting: "getUser"
    }, function(response) {
      var div, div1, div2, img, scroll;
      if ((response.user != null) && (response.user.id != null)) {
        div = document.createElement("div");
        img = document.createElement("img");
        img.setAttribute("src", "https://ohconfig.s3.amazonaws.com/icon.png");
        div1 = document.createElement("div");
        div2 = document.createElement("div");
        div.id = 'floating-div';
        div1.innerHTML = "<a href='#'><span style='color: #fff'>Office</span><span style='color: #DAEBF2'>Hours Chat</span></a>";
        div1.className = 'textDiv';
        div2.className = 'imgDiv';
        div2.appendChild(img);
        div.className = 'OfficeHoursConnect';
        div.style.position = 'fixed';
        div.style.radius = '2px';
        div.style.top = '-320px';
        div.style.right = '-480px';
        div.style.margin = '500px';
        div.style.background = "f0f";
        div.appendChild(div1);
        div.appendChild(div2);
        document.getElementsByTagName("body")[0].appendChild(div);
        div.onclick = function() {
          chrome.runtime.sendMessage({
            greeting: "sendIntercomEvent"
          });
          return window.open(response.url != null ? response.url : "https://www.officehours.co");
        };
        scroll = function() {
          div.style.top = "-320px";
          div.style.right = "-480px";
        };
        window.onscroll = scroll;
      }
    });

    return ExtendedScript;

  }).call(this);

  ExtendedScript;

}).call(this);
